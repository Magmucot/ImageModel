import numpy as np
from scipy.signal import butter, sosfiltfilt, windows


class Solver:
    def __init__(self) -> None:
        self.win_len = 320
        self.shift = 160
        self.fs = 30.0

        self.low = 0.7
        self.high = 4.0
        self.order = 2
        self.win_pow = 1.5

        win = windows.hann(self.win_len, sym=False).astype(np.float64)
        self.win = np.power(win, self.win_pow, dtype=np.float64)

        self.sos = butter(
            self.order,
            [self.low, self.high],
            btype="bandpass",
            fs=self.fs,
            output="sos",
        )

    def solve(self, signal_a: np.ndarray, signal_b: np.ndarray) -> np.ndarray:
        self._check(signal_a, signal_b)

        n = signal_a.shape[0]
        if n == 0:
            return np.empty((0, self.win_len), dtype=np.float32)

        if n == 1:
            return np.asarray(signal_a, dtype=np.float32).copy()

        fused = self._fuse(signal_a, signal_b)
        fused = self._bandpass(fused)

        out = np.empty((n, self.win_len), dtype=np.float32)
        out[:-1] = fused.reshape(n - 1, self.win_len).astype(np.float32)

        # Последнее окно сервер всё равно отбрасывает.
        out[-1] = np.asarray(signal_a[-1], dtype=np.float32)

        return out

    def _check(self, signal_a: np.ndarray, signal_b: np.ndarray) -> None:
        if not isinstance(signal_a, np.ndarray) or not isinstance(
            signal_b, np.ndarray
        ):
            raise TypeError("signal_a and signal_b must be numpy arrays")

        if signal_a.ndim != 2 or signal_b.ndim != 2:
            raise ValueError("signal_a and signal_b must have shape [N, 320]")

        if signal_a.shape != signal_b.shape:
            raise ValueError("signal_a and signal_b must have the same shape")

        if signal_a.shape[1] != self.win_len:
            raise ValueError("window length must be 320")

    def _fuse(self, signal_a: np.ndarray, signal_b: np.ndarray) -> np.ndarray:
        n = signal_a.shape[0]
        real_len = (n - 1) * self.win_len

        pad_left = self.shift
        pad_right = self.win_len
        total_len = real_len + pad_left + pad_right

        acc = np.zeros(total_len, dtype=np.float64)
        wsum = np.zeros(total_len, dtype=np.float64)

        for i in range(n):
            a_start = pad_left + i * self.win_len
            b_start = i * self.win_len

            self._add(acc, wsum, signal_a[i], a_start)
            self._add(acc, wsum, signal_b[i], b_start)

        left = pad_left
        right = pad_left + real_len

        fused = acc[left:right] / np.maximum(wsum[left:right], 1e-12)
        fused -= np.median(fused)

        return fused

    def _add(
        self,
        acc: np.ndarray,
        wsum: np.ndarray,
        x: np.ndarray,
        start: int,
    ) -> None:
        x64 = np.asarray(x, dtype=np.float64)
        stop = start + self.win_len

        acc[start:stop] += x64 * self.win
        wsum[start:stop] += self.win

    def _bandpass(self, x: np.ndarray) -> np.ndarray:
        if x.size < 32:
            return x

        base_pad = 3 * (2 * self.sos.shape[0] + 1)
        padlen = min(base_pad, x.size - 1)

        if padlen < 4:
            return x

        return sosfiltfilt(self.sos, x, padlen=padlen)